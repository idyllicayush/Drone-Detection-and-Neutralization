# MTP > 2024-11-26 3:42pm
https://universe.roboflow.com/mtp-osuqd/mtp-5iq6f

Provided by a Roboflow user
License: CC BY 4.0

